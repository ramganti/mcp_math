export function createModule(config: any) {
  return config;
}
